let dataset = [
    {
        "id": 410,
        "type": "group",
        "title": "Group 410",
        "x": -102,
        "y": 162,
        "w": 750,
        "h": 396,
        "pid": null,
        "children": [
            {
                "id": 158,
                "type": "group",
                "title": "Group 158",
                "x": -102,
                "y": 187,
                "w": 750,
                "h": 220,
                "pid": 410,
                "children": [
                    {
                        "id": 265,
                        "type": "task",
                        "title": "Task 265",
                        "content": "Content 1",
                        "x": 448,
                        "y": 212,
                        "w": 200,
                        "h": 100,
                        "pid": 158,
                        "minimized": false
                    },
                    {
                        "id": 514,
                        "type": "group",
                        "title": "Group 514",
                        "x": -102,
                        "y": 237,
                        "w": 500,
                        "h": 160,
                        "pid": 158,
                        "children": [
                            {
                                "id": 55,
                                "type": "task",
                                "title": "Task 55",
                                "content": "Content 4",
                                "x": 198,
                                "y": 287,
                                "w": 200,
                                "h": 100,
                                "pid": 514,
                                "hidden": false,
                                "minimizedBy": false,
                                "minimized": false
                            },
                            {
                                "id": 46,
                                "type": "task",
                                "title": "Task 46",
                                "content": "Content 5",
                                "startDay": "2022-4-26",
                                "endDay": "2021-4-10",
                                "pid": 514,
                                "minimized": false,
                                "x": -102,
                                "y": 262,
                                "w": 150,
                                "h": 100,
                                "hidden": false,
                                "minimizedBy": false
                            }
                        ],
                        "minimized": false
                    }
                ]
            },
            {
                "id": 187,
                "type": "task",
                "title": "Task 187",
                "content": "Content 2",
                "x": -2,
                "y": 448,
                "w": 200,
                "h": 100,
                "pid": 410
            },
            {
                "id": 85,
                "type": "task",
                "title": "Task 85",
                "content": "Content 3",
                "minimized": false,
                "x": 348,
                "y": 448,
                "w": 200,
                "h": 100,
                "pid": 410
            }
        ]
    },
    {
        "id": 422,
        "type": "group",
        "title": "Group 422",
        "x": 698,
        "y": 152,
        "w": 350,
        "h": 462,
        "pid": null,
        "children": [
            {
                "id": 510,
                "type": "group",
                "title": "Group 510",
                "x": 698,
                "y": 177,
                "w": 350,
                "h": 281,
                "pid": 422,
                "children": [
                    {
                        "id": 472,
                        "type": "task",
                        "title": "Task 472",
                        "content": "Content 9",
                        "x": 848,
                        "y": 348,
                        "w": 200,
                        "h": 100,
                        "pid": 510,
                        "hidden": false,
                        "minimizedBy": null,
                        "minimized": false
                    },
                    {
                        "id": 327,
                        "type": "task",
                        "title": "Task 327",
                        "content": "Content 7",
                        "x": 698,
                        "y": 202,
                        "w": 200,
                        "h": 100,
                        "pid": 510,
                        "hidden": false,
                        "minimizedBy": null,
                        "minimized": false
                    }
                ],
                "minimized": false
            },
            {
                "id": 632,
                "type": "task",
                "title": "Task 632",
                "content": "Content 632",
                "pid": 422,
                "x": 748,
                "y": 504,
                "w": 200,
                "h": 100,
                "minimized": false
            }
        ]
    },
    {
        "id": 492,
        "type": "task",
        "title": "Task 492",
        "content": "Content 492",
        "pid": null,
        "x": 298,
        "y": 658,
        "w": 200,
        "h": 100
    },
    {
        "id": 462,
        "type": "task",
        "title": "Task 462",
        "content": "Content 462",
        "pid": null,
        "x": -2,
        "y": 599,
        "w": 200,
        "h": 100
    }
];

let lines = [
    {
        "id": "con_2",
        "source": "85",
        "target": "492"
    },
    {
        "id": "con_3",
        "source": "492",
        "target": "632"
    },
    {
        "id": "con_4",
        "source": "55",
        "target": "327"
    }
];